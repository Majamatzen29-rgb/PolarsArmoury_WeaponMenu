let categories = [];
let baseSections = [];
let sections = [];
let currentSection = null;
let currentCategory = null;
let isOpen = false;
let searchTerm = '';
let filteredWeapons = [];
let sortMode = 'default'; // 'default', 'most', 'least'
let inventoryImageBase = 'images/';
let permissions = {
    canOpen: false,
    canGiveWeapon: false,
    canGiveAll: false,
    canGiveOthers: false
};
const favoritesStorageKey = 'polarsmenu:favorites:v1';
let favoriteItems = loadFavoriteItems();

// Listen for messages from FiveM
window.addEventListener('message', function(event) {
    const data = event.data;
    console.log('[PolarsMenu] Received message:', data);
    
    if (data.action === 'open') {
        baseSections = data.sections || [{ id: 'polars', label: 'Polars Armoury', categories: data.categories || [] }];
        sections = buildDisplaySections();
        categories = [];
        permissions = {
            canOpen: false,
            canGiveWeapon: false,
            canGiveAll: false,
            canGiveOthers: false,
            ...(data.permissions || {})
        };
        inventoryImageBase = data.imageBase || 'images/';
        console.log('[PolarsMenu] Opening UI with', sections.length, 'sections');
        openUI();
    } else if (data.action === 'close') {
        console.log('[PolarsMenu] Closing UI');
        closeUI();
    }
});

console.log('[PolarsMenu] Message listener initialized');

function openUI() {
    if (isOpen) {
        console.log('[PolarsMenu] UI already open');
        return;
    }
    console.log('[PolarsMenu] Opening UI');
    console.log('[PolarsMenu] Sections received:', sections);
    console.log('[PolarsMenu] Sections length:', sections.length);
    isOpen = true;
    searchTerm = ''; // Reset search when opening
    currentCategory = null;
    
    // Show the UI
    document.body.style.display = 'flex';
    document.body.style.visibility = 'visible';
    document.body.style.pointerEvents = 'auto';
    document.body.style.opacity = '1';
    document.body.classList.add('show');
    
    // Clear search input
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.value = '';
    }
    const targetInput = document.getElementById('targetInput');
    if (targetInput) {
        targetInput.value = '';
    }
    const targetWrapper = document.getElementById('targetWrapper');
    if (targetWrapper) {
        targetWrapper.style.display = permissions.canGiveOthers ? 'flex' : 'none';
    }
    document.getElementById('clearSearchBtn').style.display = 'none';
    
    if (sections.length > 0) {
        setActiveSection(sections[0].id);
    } else {
        console.error('[PolarsMenu] No sections available!');
        updateTotalCount();
        renderSectionSwitch();
        renderTabs();
    }
    
    // Focus search input when opened
    setTimeout(() => {
        if (searchInput) {
            searchInput.focus();
        }
    }, 100);
    
    console.log('[PolarsMenu] UI should now be visible');
    console.log('[PolarsMenu] Body classes:', document.body.className);
    console.log('[PolarsMenu] Body display:', window.getComputedStyle(document.body).display);
}

function closeUI() {
    if (!isOpen) return;
    isOpen = false;
    searchTerm = ''; // Reset search
    
    // Close instantly - no fade animation
    document.body.classList.remove('show');
    
    // Clear content immediately
    document.getElementById('tabs').innerHTML = '';
    document.getElementById('sectionSwitch').innerHTML = '';
    document.getElementById('weaponsGrid').innerHTML = '';
    categories = [];
    baseSections = [];
    sections = [];
    currentSection = null;
    currentCategory = null;
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.value = '';
    }
    document.getElementById('clearSearchBtn').style.display = 'none';
    document.body.style.display = 'none';
    document.body.style.visibility = 'hidden';
    document.body.style.pointerEvents = 'none';
    document.body.style.opacity = '0';
    
    fetch(`https://${GetParentResourceName ? GetParentResourceName() : 'polarsmenu'}/close`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

function calculateTotalWeapons() {
    let total = 0;
    categories.forEach(category => {
        if (category.weapons && Array.isArray(category.weapons)) {
            total += category.weapons.length;
        }
    });
    return total;
}

function updateTotalCount() {
    const totalCount = calculateTotalWeapons();
    const totalCountElement = document.getElementById('totalCount');
    if (totalCountElement) {
        const sectionLabel = currentSection ? currentSection.label : 'Total';
        totalCountElement.textContent = `${sectionLabel}: ${totalCount} weapons`;
    }
}

function calculateSectionTotal(section) {
    let total = 0;
    (section.categories || []).forEach(category => {
        if (category.weapons && Array.isArray(category.weapons)) {
            total += category.weapons.length;
        }
    });
    return total;
}

function loadFavoriteItems() {
    try {
        const saved = JSON.parse(localStorage.getItem(favoritesStorageKey) || '[]');
        if (!Array.isArray(saved)) {
            return new Set();
        }

        return new Set(saved.map(item => String(item || '').toUpperCase()).filter(Boolean));
    } catch (error) {
        console.warn('[PolarsMenu] Failed to load favorites:', error);
        return new Set();
    }
}

function saveFavoriteItems() {
    localStorage.setItem(favoritesStorageKey, JSON.stringify(Array.from(favoriteItems)));
}

function getAllConfiguredWeapons() {
    const weapons = new Map();

    baseSections.forEach(section => {
        (section.categories || []).forEach(category => {
            (category.weapons || []).forEach(weapon => {
                const key = String(weapon.item || '').toUpperCase();
                if (key && !weapons.has(key)) {
                    weapons.set(key, weapon);
                }
            });
        });
    });

    return weapons;
}

function buildDisplaySections() {
    const allWeapons = getAllConfiguredWeapons();
    const favorites = Array.from(favoriteItems)
        .map(item => allWeapons.get(item))
        .filter(Boolean);

    if (favorites.length === 0) {
        return [...baseSections];
    }

    return [
        {
            id: 'favorites',
            label: 'Favorites',
            categories: [
                {
                    name: 'Favorites',
                    weapons: favorites
                }
            ]
        },
        ...baseSections
    ];
}

function isFavoriteWeapon(weaponItem) {
    return favoriteItems.has(String(weaponItem || '').toUpperCase());
}

function refreshCurrentViewAfterFavorites() {
    const currentSectionId = currentSection ? currentSection.id : null;
    const currentCategoryName = currentCategory ? currentCategory.name : null;
    sections = buildDisplaySections();

    if (currentSectionId === 'favorites' && !sections.some(section => section.id === 'favorites')) {
        setActiveSection(sections[0] ? sections[0].id : null);
        return;
    }

    currentSection = sections.find(section => section.id === currentSectionId) || sections[0] || null;
    categories = currentSection ? currentSection.categories || [] : [];
    currentCategory = categories.find(category => category.name === currentCategoryName) || categories[0] || null;

    renderSectionSwitch();
    renderTabs();
    updateTotalCount();

    if (searchTerm) {
        performSearch(searchTerm);
    } else if (currentCategory) {
        setActiveCategory(currentCategory.name);
    } else {
        renderWeapons([]);
        document.getElementById('giveAllBtn').style.display = 'none';
    }
}

function toggleFavoriteWeapon(weaponItem) {
    const key = String(weaponItem || '').toUpperCase();
    if (!key) return;

    if (favoriteItems.has(key)) {
        favoriteItems.delete(key);
    } else {
        favoriteItems.add(key);
    }

    saveFavoriteItems();
    refreshCurrentViewAfterFavorites();
}

function renderSectionSwitch() {
    const sectionSwitch = document.getElementById('sectionSwitch');
    if (!sectionSwitch) return;

    sectionSwitch.innerHTML = '';

    sections.forEach(section => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'section-btn';
        button.dataset.section = section.id;
        button.innerHTML = `
            <span>${section.label}</span>
            <small>${calculateSectionTotal(section)} weapons</small>
        `;

        if (currentSection && currentSection.id === section.id) {
            button.classList.add('active');
        }

        button.addEventListener('click', () => {
            setActiveSection(section.id);
        });

        sectionSwitch.appendChild(button);
    });
}

function setActiveSection(sectionId) {
    currentSection = sections.find(section => section.id === sectionId) || sections[0] || null;
    categories = currentSection ? currentSection.categories || [] : [];
    currentCategory = null;
    filteredWeapons = [];
    searchTerm = '';

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.value = '';
    }
    const targetInput = document.getElementById('targetInput');
    if (targetInput) {
        targetInput.value = '';
    }
    const targetWrapper = document.getElementById('targetWrapper');
    if (targetWrapper) {
        targetWrapper.style.display = permissions.canGiveOthers ? 'flex' : 'none';
    }
    document.getElementById('clearSearchBtn').style.display = 'none';

    renderSectionSwitch();
    updateTotalCount();
    renderTabs();

    if (categories.length > 0) {
        setActiveCategory(categories[0].name);
    } else {
        renderWeapons([]);
        document.getElementById('giveAllBtn').style.display = 'none';
    }
}

function sortCategories() {
    const sortedCategories = [...categories];
    
    if (sortMode === 'most') {
        sortedCategories.sort((a, b) => {
            const countA = a.weapons && Array.isArray(a.weapons) ? a.weapons.length : 0;
            const countB = b.weapons && Array.isArray(b.weapons) ? b.weapons.length : 0;
            return countB - countA; // Descending (most first)
        });
    } else if (sortMode === 'least') {
        sortedCategories.sort((a, b) => {
            const countA = a.weapons && Array.isArray(a.weapons) ? a.weapons.length : 0;
            const countB = b.weapons && Array.isArray(b.weapons) ? b.weapons.length : 0;
            return countA - countB; // Ascending (least first)
        });
    }
    // 'default' keeps original order
    
    return sortedCategories;
}

function renderTabs() {
    const tabsContainer = document.getElementById('tabs');
    tabsContainer.innerHTML = '';
    
    // Get sorted categories based on current sort mode
    const sortedCategories = sortCategories();
    
    sortedCategories.forEach(category => {
        const tab = document.createElement('div');
        tab.className = 'tab';
        tab.dataset.category = category.name;
        
        // Get weapon count for this category
        const weaponCount = category.weapons && Array.isArray(category.weapons) ? category.weapons.length : 0;
        
        tab.innerHTML = `<span class="tab-name">${category.name}</span><span class="tab-count">(${weaponCount})</span>`;
        
        tab.addEventListener('click', () => {
            setActiveCategory(category.name);
        });
        
        tabsContainer.appendChild(tab);
    });
}

function filterWeapons(weapons, searchQuery) {
    if (!searchQuery || searchQuery.trim() === '') {
        return weapons;
    }
    
    const query = searchQuery.toLowerCase().trim();
    
    return weapons.filter(weapon => {
        const nameMatch = weapon.name.toLowerCase().includes(query);
        const itemMatch = weapon.item.toLowerCase().includes(query);
        return nameMatch || itemMatch;
    });
}

function setActiveCategory(categoryName) {
    // Update active tab
    document.querySelectorAll('.tab').forEach(tab => {
        if (tab.dataset.category === categoryName) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
    
    // Find and set current category
    currentCategory = categories.find(cat => cat.name === categoryName);
    
    if (currentCategory) {
        // Only show category weapons if no search is active (search is always global)
        const weaponsToRender = !searchTerm ? currentCategory.weapons : filteredWeapons;
        
        filteredWeapons = weaponsToRender;
        renderWeapons(weaponsToRender);
        
        // Show "Give All" button if category has weapons and no search is active
        const giveAllBtn = document.getElementById('giveAllBtn');
        if (permissions.canGiveAll && currentCategory.weapons && currentCategory.weapons.length > 0 && !searchTerm) {
            giveAllBtn.style.display = 'flex';
            giveAllBtn.dataset.category = categoryName;
            giveAllBtn.dataset.section = currentSection ? currentSection.id : '';
        } else {
            giveAllBtn.style.display = 'none';
            delete giveAllBtn.dataset.category;
            delete giveAllBtn.dataset.section;
        }
    }
}

function performSearch(query) {
    searchTerm = query;
    const clearBtn = document.getElementById('clearSearchBtn');
    
    if (searchTerm && searchTerm.trim() !== '') {
        clearBtn.style.display = 'flex';
        
        // Global search across ALL categories
        let allWeapons = [];
        categories.forEach(category => {
            if (category.weapons && Array.isArray(category.weapons)) {
                allWeapons = allWeapons.concat(category.weapons);
            }
        });
        
        const filtered = filterWeapons(allWeapons, searchTerm);
        filteredWeapons = filtered;
        
        renderWeapons(filtered);
        
        // Hide "Give All" button when searching
        document.getElementById('giveAllBtn').style.display = 'none';
        
        // Remove active tab highlight when searching globally
        document.querySelectorAll('.tab').forEach(tab => {
            tab.classList.remove('active');
        });
    } else {
        // No search term - clear search and restore category view
        clearBtn.style.display = 'none';
        
        // Restore current category view
        if (currentCategory) {
            setActiveCategory(currentCategory.name);
        } else if (categories.length > 0) {
            setActiveCategory(categories[0].name);
        }
    }
}

function renderWeapons(weapons) {
    const grid = document.getElementById('weaponsGrid');
    grid.innerHTML = '';
    
    if (!weapons || weapons.length === 0) {
        console.log('[PolarsMenu] No weapons to display');
        const noResults = document.createElement('div');
        noResults.className = 'no-results';
        noResults.innerHTML = `
            <div style="text-align: center; padding: 60px 20px; color: rgba(255, 255, 255, 0.6);">
                <div style="font-size: 48px; margin-bottom: 20px;">🔍</div>
                <div style="font-size: 20px; font-weight: 600; margin-bottom: 10px;">No weapons found</div>
                <div style="font-size: 14px;">${searchTerm ? 'Try a different search term' : 'No weapons in this category'}</div>
            </div>
        `;
        grid.appendChild(noResults);
        return;
    }
    
    console.log('[PolarsMenu] Rendering', weapons.length, 'weapons');
    
    // Use DocumentFragment for better performance when rendering many items
    const fragment = document.createDocumentFragment();
    
    weapons.forEach((weapon, index) => {
        const card = document.createElement('div');
        card.className = 'weapon-card';
        card.dataset.weapon = weapon.item;
        card.dataset.ammo = weapon.ammo || '';

        const favoriteBtn = document.createElement('button');
        favoriteBtn.type = 'button';
        favoriteBtn.className = 'favorite-btn';
        favoriteBtn.dataset.favoriteWeapon = weapon.item;
        favoriteBtn.textContent = isFavoriteWeapon(weapon.item) ? '★' : '☆';
        favoriteBtn.title = isFavoriteWeapon(weapon.item) ? 'Remove from favorites' : 'Add to favorites';
        favoriteBtn.setAttribute('aria-label', favoriteBtn.title);
        if (isFavoriteWeapon(weapon.item)) {
            favoriteBtn.classList.add('active');
        }
        
        // Get image path for weapon
        const imagePath = getWeaponImage(weapon.item);
        const fallbackIcon = getWeaponIcon(weapon.category);
        
        const iconDiv = document.createElement('div');
        iconDiv.className = 'weapon-icon';
        
        const img = document.createElement('img');
        img.src = imagePath;
        img.alt = weapon.name;
        img.className = 'weapon-image';
        img.loading = 'lazy'; // Lazy load images for better performance
        img.dataset.fallbackStage = '0';
        img.onerror = function() {
            if (this.dataset.fallbackStage === '0') {
                this.dataset.fallbackStage = '1';
                this.src = getWeaponImage(weapon.item, true);
                return;
            }

            this.style.display = 'none';
            iconDiv.innerHTML = fallbackIcon;
            iconDiv.style.fontSize = '48px';
        };
        
        iconDiv.appendChild(img);
        
        const nameDiv = document.createElement('div');
        nameDiv.className = 'weapon-name';
        nameDiv.textContent = weapon.name;
        
        const itemDiv = document.createElement('div');
        itemDiv.className = 'weapon-item';
        itemDiv.textContent = weapon.item;
        
        card.appendChild(favoriteBtn);
        card.appendChild(iconDiv);
        card.appendChild(nameDiv);
        card.appendChild(itemDiv);

        if (weapon.ammo) {
            const ammoWrap = document.createElement('label');
            ammoWrap.className = 'ammo-control';

            const ammoLabel = document.createElement('span');
            ammoLabel.textContent = 'Ammo amount';

            const ammoInput = document.createElement('input');
            ammoInput.className = 'ammo-input';
            ammoInput.type = 'number';
            ammoInput.min = '0';
            ammoInput.max = '10000';
            ammoInput.step = '1';
            ammoInput.placeholder = '0';
            ammoInput.inputMode = 'numeric';
            ammoInput.dataset.weaponAmmo = weapon.item;

            const ammoItem = document.createElement('small');
            ammoItem.className = 'ammo-item';
            ammoItem.textContent = weapon.ammo;

            ammoWrap.appendChild(ammoLabel);
            ammoWrap.appendChild(ammoInput);
            ammoWrap.appendChild(ammoItem);
            card.appendChild(ammoWrap);
        }

        if (permissions.canGiveWeapon) {
            const actionRow = document.createElement('div');
            actionRow.className = 'weapon-actions';

            if (permissions.canGiveOthers) {
                const cardTargetWrap = document.createElement('label');
                cardTargetWrap.className = 'card-target-wrapper';

                const cardTargetLabel = document.createElement('span');
                cardTargetLabel.textContent = 'Server ID';

                const cardTargetInput = document.createElement('input');
                cardTargetInput.className = 'card-target-input';
                cardTargetInput.type = 'number';
                cardTargetInput.min = '1';
                cardTargetInput.step = '1';
                cardTargetInput.placeholder = 'Self';
                cardTargetInput.inputMode = 'numeric';

                cardTargetWrap.appendChild(cardTargetLabel);
                cardTargetWrap.appendChild(cardTargetInput);
                actionRow.appendChild(cardTargetWrap);
            }

            const giveBtn = document.createElement('button');
            giveBtn.type = 'button';
            giveBtn.className = 'weapon-give-btn';
            giveBtn.textContent = 'Give';
            giveBtn.dataset.giveWeapon = weapon.item;

            actionRow.appendChild(giveBtn);
            card.appendChild(actionRow);
        }
        
        fragment.appendChild(card);
    });
    
    // Append all cards at once for better performance
    grid.appendChild(fragment);
    
    // Use event delegation instead of individual listeners on each card for better performance
    // Remove old listener if exists and add new one
    grid.onclick = function(e) {
        const favoriteBtn = e.target.closest('.favorite-btn');
        if (favoriteBtn) {
            toggleFavoriteWeapon(favoriteBtn.dataset.favoriteWeapon);
            return;
        }

        if (e.target.closest('.ammo-control') || e.target.closest('.card-target-wrapper')) {
            return;
        }

        const giveBtn = e.target.closest('.weapon-give-btn');
        if (giveBtn) {
            const card = giveBtn.closest('.weapon-card');
            const ammoInput = card.querySelector('.ammo-input');
            const targetInput = card.querySelector('.card-target-input');
            const ammoAmount = ammoInput ? parseInt(ammoInput.value, 10) || 0 : 0;
            const targetId = targetInput ? parseInt(targetInput.value, 10) || 0 : 0;
            selectWeapon(card.dataset.weapon, ammoAmount, targetId);
        }
    };
}

function getWeaponImage(weaponItem, lowercase = false) {
    const itemName = lowercase ? weaponItem.toLowerCase() : weaponItem;
    return `${inventoryImageBase}${itemName}.png`;
}

function getWeaponIcon(category) {
    const icons = {
        'Melee': '⚔️',
        'Melee v2': '🗡️',
        'Melee v3': '🔪',
        'Prison': '🔒',
        'Throwable': '🎯',
        'Zombie': '🧟',
        'Christmas': '🎄',
        'Halloween': '🎃',
        'Female': '💅',
        'Valentine': '💝',
        'Belt2Ass': '👔'
    };
    
    return icons[category] || '⚔️';
}

function getTargetServerId(targetId) {
    if (!permissions.canGiveOthers) {
        return null;
    }

    if (targetId && targetId > 0) {
        return targetId;
    }

    const targetInput = document.getElementById('targetInput');
    const headerTargetId = targetInput ? parseInt(targetInput.value, 10) : 0;

    return headerTargetId > 0 ? headerTargetId : null;
}

function selectWeapon(weaponItem, ammoAmount = 0, targetId = null) {
    console.log('[PolarsMenu] Selecting weapon:', weaponItem, 'ammo:', ammoAmount);

    if (!permissions.canGiveWeapon) {
        console.warn('[PolarsMenu] This user cannot give weapons.');
        return;
    }
    
    fetch(`https://${GetParentResourceName ? GetParentResourceName() : 'polarsmenu'}/selectWeapon`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            weapon: weaponItem,
            ammoAmount: ammoAmount,
            targetId: getTargetServerId(targetId)
        })
    }).then(() => {
        console.log('[PolarsMenu] Weapon selected:', weaponItem);
    }).catch(error => {
        console.error('[PolarsMenu] Error selecting weapon:', error);
    });
}

function giveAllWeapons(sectionId, categoryName) {
    if (!permissions.canGiveAll) {
        console.warn('[PolarsMenu] This user cannot use Give All.');
        return;
    }

    const category = categories.find(cat => cat.name === categoryName);
    if (!category || !category.weapons || category.weapons.length === 0) {
        console.error('[PolarsMenu] No weapons in category:', categoryName);
        return;
    }
    
    const ammoByWeapon = {};
    document.querySelectorAll('.weapon-card').forEach(card => {
        if (!card.dataset.weapon) return;

        const ammoInput = card.querySelector('.ammo-input');
        if (!ammoInput) return;

        const ammoAmount = parseInt(ammoInput.value, 10) || 0;
        if (ammoAmount > 0) {
            ammoByWeapon[card.dataset.weapon] = ammoAmount;
        }
    });

    console.log('[PolarsMenu] Giving all weapons from category:', categoryName);
    console.log('[PolarsMenu] Weapons count:', category.weapons.length);
    
    // Disable button while processing
    const giveAllBtn = document.getElementById('giveAllBtn');
    giveAllBtn.disabled = true;
    giveAllBtn.textContent = 'Giving...';
    
    fetch(`https://${GetParentResourceName ? GetParentResourceName() : 'polarsmenu'}/giveAllWeapons`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            section: sectionId,
            category: categoryName,
            weapons: category.weapons.map(weapon => weapon.item),
            ammoByWeapon: ammoByWeapon,
            targetId: getTargetServerId()
        })
    }).then(() => {
        console.log('[PolarsMenu] Give all request sent');
        // Re-enable button after a delay
        setTimeout(() => {
            giveAllBtn.disabled = false;
            giveAllBtn.textContent = 'Give All';
        }, 2000);
    }).catch(error => {
        console.error('[PolarsMenu] Error giving all weapons:', error);
        giveAllBtn.disabled = false;
        giveAllBtn.textContent = 'Give All';
    });
}

// Close button handler
document.getElementById('closeBtn').addEventListener('click', function() {
    closeUI();
});

// Give All button handler
document.getElementById('giveAllBtn').addEventListener('click', function() {
    const sectionId = this.dataset.section;
    const categoryName = this.dataset.category;
    if (categoryName) {
        giveAllWeapons(sectionId, categoryName);
    }
});

// Sort select handler
const sortSelect = document.getElementById('sortSelect');
if (sortSelect) {
    sortSelect.addEventListener('change', function(e) {
        sortMode = e.target.value;
        renderTabs(); // Re-render categories with new sort order
        
        // Maintain active category highlight after sorting
        if (currentCategory) {
            setActiveCategory(currentCategory.name);
        }
    });
}

// Debounce function for search input
let searchTimeout = null;
function debounceSearch(value) {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        performSearch(value);
    }, 150); // 150ms debounce for smoother typing
}

// Search input handler
const searchInput = document.getElementById('searchInput');
if (searchInput) {
    searchInput.addEventListener('input', function(e) {
        // Use debounced search for better performance
        debounceSearch(e.target.value);
    }, { passive: true });
    
    // Allow Enter key to select first result
    searchInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && filteredWeapons.length > 0) {
            e.preventDefault();
            selectWeapon(filteredWeapons[0].item);
        } else if (e.key === 'Escape') {
            clearSearch();
            closeUI();
        }
    });
}

// Clear search button handler
const clearSearchBtn = document.getElementById('clearSearchBtn');
if (clearSearchBtn) {
    clearSearchBtn.addEventListener('click', function() {
        clearSearch();
    });
}

function clearSearch() {
    // Clear any pending search debounce
    if (searchTimeout) {
        clearTimeout(searchTimeout);
        searchTimeout = null;
    }
    
    searchTerm = '';
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.value = '';
    }
    document.getElementById('clearSearchBtn').style.display = 'none';
    
    // Restore current category view
    if (currentCategory) {
        setActiveCategory(currentCategory.name);
    } else if (categories.length > 0) {
        setActiveCategory(categories[0].name);
    }
}

// ESC key handler (backup)
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape' && isOpen) {
        if (searchTerm) {
            clearSearch();
        } else {
            closeUI();
        }
    }
    
    // Ctrl+F or Cmd+F to focus search
    if ((event.ctrlKey || event.metaKey) && event.key === 'f' && isOpen) {
        event.preventDefault();
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }
});

// Initialize - hide UI by default
document.body.style.display = 'none';
document.body.style.visibility = 'hidden';
document.body.style.pointerEvents = 'none';
document.body.style.opacity = '0';

