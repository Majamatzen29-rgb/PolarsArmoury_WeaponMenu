fx_version 'cerulean'
game 'gta5'

author 'Polars Armoury'
description 'Weapon Menu - Browse and select weapons'
version '1.0.1'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/images/*.png'
}
escrow_ignore {
    "config.lua"
}

dependency '/assetpacks'