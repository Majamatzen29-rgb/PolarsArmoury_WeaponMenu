Put this in your server.cfg 

add_ace group.admin polarsmenu.admin allow
add_ace group.mod polarsmenu.mod allow